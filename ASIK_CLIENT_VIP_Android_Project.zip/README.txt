ASIK CLIENT VIP — Android Studio project

What this starter app does:
- Shows a dark/neon ASIK CLIENT VIP game-launcher dashboard.
- Provides buttons to open Free Fire MAX, Free Fire, COD Mobile and Mobile Legends if installed.
- Does not modify games or include cheats, ESP, aimbot, injection, or memory editing.

Build APK:
1. Install Android Studio on a computer.
2. Open this ASIK_CLIENT_VIP folder as a project.
3. Allow Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK output location.

Note: This is the source project, not a precompiled APK. A computer with Android Studio is required to compile it.
