package com.asik.clientvip;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(7, 10, 16);
    private final int panel = Color.rgb(20, 27, 36);
    private final int cyan = Color.rgb(0, 235, 220);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(28), dp(20), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView brand = new TextView(this);
        brand.setText("⚡ ASIK CLIENT VIP");
        brand.setTextColor(cyan);
        brand.setTextSize(27);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("PREMIUM GAME LAUNCHER");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(7), 0, dp(22));
        root.addView(subtitle);

        addGame(root, "FREE FIRE MAX", "Garena • Game Launcher", "com.dts.freefiremax", "FF MAX");
        addGame(root, "FREE FIRE", "Garena • Game Launcher", "com.dts.freefireth", "FREE FIRE");
        addGame(root, "CALL OF DUTY MOBILE", "Activision • Game Launcher", "com.activision.callofduty.shooter", "CODM");
        addGame(root, "MOBILE LEGENDS", "MOONTON • Game Launcher", "com.mobile.legends", "MLBB");

        TextView info = new TextView(this);
        info.setText("TOOLS\\n• Game launch shortcuts\\n• Device-friendly dashboard\\n• Profile & settings (basic)");
        info.setTextColor(Color.rgb(185, 199, 210));
        info.setTextSize(13);
        info.setPadding(dp(16), dp(15), dp(16), dp(15));
        info.setBackground(round(panel, 18));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(8);
        root.addView(info, ip);

        TextView footer = new TextView(this);
        footer.setText("POWERED BY ASIK  •  VERSION 1.0");
        footer.setTextColor(cyan);
        footer.setTextSize(10);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer);

        setContentView(scroll);
    }

    private void addGame(LinearLayout root, String title, String desc, String pkg, String shortName) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(round(panel, 18));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(13);
        root.addView(card, cp);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = new TextView(this);
        icon.setText(shortName);
        icon.setTextColor(bg);
        icon.setTextSize(12);
        icon.setTypeface(null, Typeface.BOLD);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(round(cyan, 13));
        row.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(13), 0, 0, 0);
        TextView name = new TextView(this);
        name.setText(title);
        name.setTextColor(Color.WHITE);
        name.setTextSize(15);
        name.setTypeface(null, Typeface.BOLD);
        labels.addView(name);
        TextView detail = new TextView(this);
        detail.setText(desc);
        detail.setTextColor(Color.LTGRAY);
        detail.setTextSize(11);
        detail.setPadding(0, dp(4), 0, 0);
        labels.addView(detail);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
        card.addView(row);

        Button launch = new Button(this);
        launch.setText("OPEN GAME  →");
        launch.setTextColor(bg);
        launch.setAllCaps(false);
        launch.setTypeface(null, Typeface.BOLD);
        launch.setBackground(round(cyan, 12));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(46));
        bp.topMargin = dp(14);
        card.addView(launch, bp);
        launch.setOnClickListener(v -> openGame(pkg, title));
    }

    private void openGame(String pkg, String title) {
        Intent intent = getPackageManager().getLaunchIntentForPackage(pkg);
        if (intent != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, title + " is not installed.", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
